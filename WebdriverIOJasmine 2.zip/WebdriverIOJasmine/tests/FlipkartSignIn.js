const data = require('../wdio.conf').config.data;
const flipkartComp = require('../framework/components/flipkart_component');

describe("Testing Flipkart Application by Searching, adding and deleting the product Scenarios", () => {

    it("FlipkartSignIn", async() => {
        
        /** Search for the Mobiles */
        await flipkartComp.searchForMobiles(data, 0);

        /** Selects the Mobile in application  */
        await flipkartComp.selectMobile();

        /** Adds the selected Product to the cart */
        await flipkartComp.addToCart();

        /** Removes the Product from the cart */
        await flipkartComp.removeFromCart();
        
    });
    
});