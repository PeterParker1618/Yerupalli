/**
 * Initializing and importing all the libraries.
 *  => Allure Reporter: For Accessing reporter.
 *  => fs-extra: File system access.
 *  => path: Path access.
 */
const allureReporter = require('@wdio/allure-reporter').default;
const fs = require('fs-extra');
const path = require('path');

/**
 * Reporter Class
 */
class Reporter{

    /**
     * HTML Report : Logging in report
     * @param {string} message: Message to be printed in report
     */
    logMessage(message){
        /* Add Message */
        process.emit('test:log', message);
    }

    /**
     * HTML Report : To take screenshot.
     * @param {string} message: screenshot title.
     */
    takeScreenshot(message){
        /** Generating time stamp */
        const timestamp = Date(Date.now()).replace(/ /g,'').split('(')[0].replace("+","").replace(":","");
        /** Ensure Directory */
        fs.ensureDirSync('reports/html-reports/screenshots/');
        /** Generating File Path */
        const filepath = path.join('reports/html-reports/screenshots/', timestamp + '.png');
        /** Saving SCreenshot to the path */
        browser.saveScreenshot(filepath);
        /** Adding title to the screenshot in the reporter */
        process.emit('test:screenshot', filepath);
        /** Return the screenshot instance */
        return this;
    }

    /**
     * Add HTML Report.
     * @param {string} message : Report log.
     * @param {Boolean} addScreenshot : Screenshot to be added or not.
     */
    addHtmlReport(message, addScreenshot){
        if(addScreenshot == true){
            this.logMessage(message);
            this.takeScreenshot(message);
        }else{
            this.logMessage(message);
        }
    }

    /**
     * Reporter Function to add reporter log.
     * @param {string} message : Report log.
     * @param {string} status : Log status: passed, failed.
     * @param {Boolean} addScreenshot : Screenshot to be added or not.
     */
    addStep(message, status, addScreenshot){
        console.log(status + " : " + message);
        if(status == "passed") {
            if(addScreenshot){
                browser.takeScreenshot();
                allureReporter.addStep(status + " : " + message, {name:browser.takeScreenshot()}, status);
                this.addHtmlReport(status + " : " + message, addScreenshot);
            }else{
                allureReporter.addStep(status + " : " + message, {}, status);
                this.addHtmlReport(status + " : " + message);
            }
        }else{
            addScreenshot = true;
            browser.takeScreenshot();
            allureReporter.addStep(status + " : " + message, {name:browser.takeScreenshot()}, status);
            this.addHtmlReport(status + " : " + message, addScreenshot);
            var stack = new Error().stack;
            var errMessage = new Error().message;
            fail(status + " : " + errMessage + "\n" + stack);
        }
    }
}

/** Export as class Object */
module.exports = new Reporter();