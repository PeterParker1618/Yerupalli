/** Page Object Class */
const Page = require('./page');

/**
 * Example Page
 */
class FlipkartPage extends Page {

    /**
     * Navigate to Url
     * @param {string} path : URL
     */
    async open(path){
        /* Navigate the browser address to provided url. */
        await super.open(path);
    }

    /** Flipkart Username or Email Placeholder*/
    username = async function(){return await browser.$('//span[text()="Enter Email/Mobile number"]/../../input');}
    /** Flipkart Password Placeholder */
    password = async function(){return await browser.$('//span[text()="Enter Password"]/../../input');}
    /** Login Button */
    loginBtn = async function(){return await browser.$('(//span[text()="Login"])[2]/..');}
    /** Search field */
    searchField = async function(){return await browser.$('//input[@name="q"]');}
    /** Search Button */
    searchBtn = async function(){return await browser.$('//button[@class="L0Z3Pu"]');}
    /** First Mobile Option */
    firstOptMobile = async function(){return await browser.$('(//div[@class="col col-7-12"])[1]');}
    /** Add to cart Button */
    addToCartBtn = async function(){return await browser.$('//button[text()="ADD TO CART"]');}
    /** Buy Now Button */
    buyNowBtn = async function(){return await browser.$('///button[text()="BUY NOW"]');}
    /** My cart Icon */
    myCartIcon = async function(){return await browser.$('//span[text()="Cart"]/..');}

    /** Remove Button */
    removeBtn = async function(){return await browser.$('//div[text()="Remove"]');}
    /** Remove Button */
    shpNowBtn = async function(){return await browser.$('//span[text()="Shop now"]/..');}
    /** My Account Drop Down */
    myaccDD = async function(){return await browser.$('//div[text()="My Account"]');}
    /** Logout Button */
    logoutBtn = async function(){return await browser.$('//div[text()="Logout"]');}
}

/** Exports as Class Object */
module.exports = new FlipkartPage();