/**
 * Page Object base class.
 */
module.exports = class Page{

    constructor(){

    }

    /**
     * Returns Web Element to be searched by name attribute property
     * @param {string} locatorName : Name Attribute Value
     * @returns {string} XML Path for name attribute
     */
    getLocatorByName(locatorName){
        return '[name="' + locatorName + '"]' ;
    }

    /**
     * Returns Web Element to be searched by xpath
     * @param {string} locatorXpath : XML path For the Element
     * @returns {Object} Web Element
     */
    getLocatorByXpath(locatorXpath){
        return async function() { 
            return await browser.$(locatorXpath); 
        };
    }

    /**
     * Returns Web Element to be searched by its Test ID
     * @param {string} testID : Element Test ID
     * @returns {Object} Web Element
     */
    getLocatorByTestId(testID){
        return async function() { 
            return await browser.$('[data-testid="'+ testID +'"]'); 
        };
    }

    /**
     * Returns Web Element to be searched by its Attribute Property Value
     * @param {string} propertyName : PropertyName Eg:Class
     * @param {string} propertyValue : PropertyValue
     * @returns {Object} Web Element
     */
    getLocatorByProperty(propertyName,propertyValue){
        return async function() { 
            return await browser.$('['+ propertyName +'="'+ propertyValue +'"]'); 
        };
    }

    /**
     * Returns Web Element to be searched by its inner Text
     * @param {string} elementText : Element Inner Text
     * @returns {Object} Web Element
     */
    getLocatorByText(elementText){
        return async function() { 
            return await browser.$("//*[text()='"+elementText+"']"); 
        };
    }

    /**
     * Navigate to url
     * @param {string} path : URL
     */
    async open(path){
        /* Maximize browser window */
        await browser.maximizeWindow();
        /* Navigate the browser address to provided url. */
        await browser.url(path);
    }



}