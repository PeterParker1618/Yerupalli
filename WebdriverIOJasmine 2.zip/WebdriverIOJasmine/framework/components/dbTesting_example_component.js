const db = require('../libs/db_handler/connect_to_oracle');
/**
 * Connect to DB Class
 */
class ConnectDB {
    /**
     * Run Query and fetch data
     * @param {string} DBPassword : DB Password
     * @param {string} Query : DB Query
     * @param {string} DBUsername : DB Username
     * @returns {string} Database Query Result
     */
    async getDBData(DBUsername, DBPassword, Query){
        await db.connect("(DESCRIPTION =(ADDRESS = (PROTOCOL = TCP)(HOST = @hostnamehere )(PORT = 1521))(CONNECT_DATA =(SERVICE_NAME = @servicenamehere)))",
            DBUsername,DBPassword);
        var res = await db.connExecute(Query);
        await db.connRelease();
        return res;
    }

    /**
     * Example Method
     */
    async getExampleData(){
        var response = await this.getDBData("USERNAME_HERE","PASSWORD_HERE","QUERY_HERE");
        var dbname = response.rows[0].NAME_ROW_HEADERNAME;
        console.log(dbname); 
    }
    
}

module.exports = new ConnectDB();