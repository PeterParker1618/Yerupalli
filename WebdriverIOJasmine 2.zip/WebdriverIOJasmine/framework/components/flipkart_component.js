const flipkartPage = require('../pages/flipkart_page');
const webDriver = require('../libs/keywords/keywords');
const reporter = require('../reporter/reporter');

class FlipkartComponent {
    /**
     * Flipkart Login 
     */
    async loginToFlipkart(data){
        
        await webDriver.waitForDisplayed(await flipkartPage.username(), 20000);
        await webDriver.setValue(await flipkartPage.username(), data.get('Username'));
        reporter.addStep("Entered Username.","passed");

        await webDriver.waitForDisplayed(await flipkartPage.password(), 20000);
        await webDriver.setValue(await flipkartPage.password(), data.get('Password'));
        reporter.addStep("Entered Password.","passed");

        await webDriver.click(await flipkartPage.loginBtn());
        reporter.addStep("Clicked on Login Button","passed");

        
    }


    async searchForMobiles(data, index){
        await webDriver.waitForDisplayed(await flipkartPage.searchField());

        await webDriver.setValue(await flipkartPage.searchField(), data.get('SearchOption')[index]);
        reporter.addStep("Entered the Option as: "+data.get('SearchOption')[index],"passed");

        await webDriver.click(await flipkartPage.searchBtn());
        reporter.addStep("Clicked on Search Button","passed");
    }

    async selectMobile(){
        await webDriver.waitForDisplayed(await flipkartPage.firstOptMobile());
        await webDriver.click(await flipkartPage.firstOptMobile());
        reporter.addStep("Selected the Mobile Phone","passed");
    }

    async addToCart(){
        var switchWindow = await browser.getWindowHandles();
        await browser.switchToWindow(switchWindow[1]);

        await webDriver.waitForDisplayed(await flipkartPage.addToCartBtn());
        await webDriver.click(await flipkartPage.addToCartBtn());
        reporter.addStep("Clicked on Add to cart button","passed");
    }

    async removeFromCart(){

        await webDriver.click(await flipkartPage.myCartIcon());
        reporter.addStep("Clicked on My Cart Icon Button","passed");

        await webDriver.waitForDisplayed(await flipkartPage.removeBtn());
        await webDriver.click(await flipkartPage.removeBtn());
        await webDriver.click(await flipkartPage.removeBtn());
        reporter.addStep("Clicked on Remove Button","passed");

        await webDriver.waitForDisplayed(await flipkartPage.shpNowBtn());
        await webDriver.click(await flipkartPage.shpNowBtn());

    }

    async signOutFromFlipkart(){
        await webDriver.clickInBrowser(await flipkartPage.myaccDD());
        reporter.addStep("Clicked on My Account Button", "passed");
        await webDriver.click(await flipkartPage.logoutBtn());
        reporter.addStep("Clicked on Logout Button", "passed");

        await webDriver.waitForDisplayed(await flipkartPage.username());
    }
}

module.exports = new FlipkartComponent();